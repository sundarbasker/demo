export const environment = {
  production: true,
  filterDetail : "http://dummy.restapiexample.com/api/v1/employees"
};
