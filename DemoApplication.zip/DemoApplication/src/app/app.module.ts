import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FirstOneComponent } from './Components/first-one/first-one.component';
import { SecondTwoComponent } from './Components/second-two/second-two.component';
import { ThirdOneComponent } from './Components/third-one/third-one.component';
import { HomeComponent } from './Components/home/home.component';
import { DataServiceService } from './service/data-service.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { HeaderComponent } from './Components/header/header.component';
import { FooterComponent } from './Components/footer/footer.component';


@NgModule({
  declarations: [
    AppComponent,
    FirstOneComponent,
    SecondTwoComponent,
    ThirdOneComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  
  providers: [
  DataServiceService
],

  bootstrap: [AppComponent]
})
export class AppModule { }
