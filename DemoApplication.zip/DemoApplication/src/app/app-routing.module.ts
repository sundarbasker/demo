import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FirstOneComponent } from './Components/first-one/first-one.component';
import { SecondTwoComponent } from './Components/second-two/second-two.component';
import { ThirdOneComponent } from './Components/third-one/third-one.component';
import { AppComponent } from './app.component';
import { HomeComponent } from './Components/home/home.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'first', component: FirstOneComponent },
  { path: 'second', component: SecondTwoComponent },
  { path: 'third', component: ThirdOneComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
