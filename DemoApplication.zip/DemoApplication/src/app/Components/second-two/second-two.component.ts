import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-second-two',
  templateUrl: './second-two.component.html',
  styleUrls: ['./second-two.component.css']
})
export class SecondTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
